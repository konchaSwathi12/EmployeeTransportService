package com.transport.dataservice.dataservice;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ParameterizedPreparedStatementSetter;
import org.springframework.stereotype.Service;

import com.transport.dataservice.dataserviceconfig.DataServiceConfig;
import com.transport.dataservice.entity.EmployeeData;
import com.transport.dataservice.exception.RequestNotFoundException;
import com.transport.dataservice.repository.DataServiceJdbcRepository;
import com.transport.dataservice.repository.DataServiceRepository;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;
@Service
@Data
@Slf4j
public class DataServiceInterfaceImpl implements DataServiceInterface {

	
	@Autowired
	private DataServiceRepository dataServiceRepository;
	
	@Autowired
	private DataServiceJdbcRepository dataServiceJdbcRepository;
	
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	@Autowired
	DataServiceConfig properties;
	
	@Override
	public List<EmployeeData> findAllRequests() {
		
		
		if(properties.getKey().equals("Y"))
		{
			log.info("Spring DataJpa is executing");
			if(this.dataServiceRepository.findAll().size()>0)
				return this.dataServiceRepository.findAll();
			else
				
			throw new RequestNotFoundException("No Employee Record Found");
		}
		
		else
		{
			log.info("jdbcTemplate is executing");
			if(this.dataServiceJdbcRepository.findAllRequests().size()>0)
				return this.dataServiceRepository.findAll();
			else	
			throw new RequestNotFoundException("No Employee Record Found");
		}
			
	}

	@Override
	public EmployeeData findRequestByEmpId(Integer empId) {
		
		EmployeeData employeeData=null;
		if(properties.getKey().equals("Y"))
		{
			 employeeData=this.dataServiceRepository.findByEmpId(empId);
			
		}
		else
			 employeeData=this.dataServiceJdbcRepository.findRequestByEmpId(empId);	
		
		 if(employeeData!=null)	
			 return employeeData;
		else
		{
			log.info("throw exception");
			throw new RequestNotFoundException("No request Available for this Id "+empId);
		}
		
	}

	@Override
	public EmployeeData saveEmployeeRequest(EmployeeData employeeData) {
		
		
		 if(employeeData.getDropLocation()!=null&&employeeData.getPickupLocation()!=null)
			{
				 if(properties.getKey().equals("Y"))
				 {
					 this.dataServiceRepository.save(employeeData);
				 }
				 else
					 this.dataServiceJdbcRepository.saveEmployeeRequest(employeeData);
				 
				return  employeeData;
			}
		 else
			throw new RuntimeException("Could not add record!!!");
	}
	

	@Override
	public boolean changeStatus() {
		
		this.dataServiceRepository.modifyStatus();
		return true;
	}

	@Override
	public Boolean deleteRequest(Integer id) {
		
		 if(properties.getKey().equals("Y"))
		 {
			 this.dataServiceRepository.deleteEmployeeRequest(id);
		 }
		 else
			 this.dataServiceJdbcRepository.deleteEmployeeRequest(id);
	 
	 
	 return true;
	}

	@Override
	public void modifyBatchRequests(List<EmployeeData> requestData) {
		 int batchSize=50;
		 ParameterizedPreparedStatementSetter<EmployeeData> parameterizedPreparedStatementSetter = (ps,req) -> ps.setInt(1, req.getEmpId());
		jdbcTemplate.batchUpdate(properties.getBatchQuery(), requestData, batchSize, parameterizedPreparedStatementSetter);
		
	}

}
