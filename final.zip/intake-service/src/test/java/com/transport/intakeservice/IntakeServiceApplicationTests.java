package com.transport.intakeservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IntakeServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
